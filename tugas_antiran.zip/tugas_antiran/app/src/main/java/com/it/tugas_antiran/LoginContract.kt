package com.it.tugas_antrian.login

import com.it.tugas_antrian.base.BaseView
import com.it.tugas_antrian.model.LoginResponse.Value

interface LoginContract {

    interface LoginView : BaseView {
        fun checkAlreadyLogin()
        fun onLoginBtnClick()
        fun onLoginResult(result: Boolean?)
        fun moveToNextScreen()
        fun saveToken(token : String)
    }

    interface LoginPresenter {
        fun doLogin(name: String, passwd: String)
        fun moveToNextActivity()

    }
}