package com.it.tugas_antrian.base

import com.it.tugas_antrian.navigator.Navigator

abstract class BasePresenter<V : BaseView>{
    val navigator = Navigator.getNavigator()
    abstract fun start(view:V)
    abstract fun destroy()

}