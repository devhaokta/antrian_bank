package com.it.tugas_antrian.model

data class ApiResponse(
        var `data`: LoginResponse.Value,
        var message: String,
        var status: Boolean
        )

