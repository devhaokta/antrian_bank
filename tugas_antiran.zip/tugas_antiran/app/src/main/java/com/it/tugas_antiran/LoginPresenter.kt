package com.it.tugas_antrian.login

import android.content.SharedPreferences
import com.it.tugas_antrian.api.ApiManager
import com.it.tugas_antrian.api.ResponseCallBack
import com.it.tugas_antrian.base.BaseActivity
import com.it.tugas_antrian.base.BasePresenter
import com.it.tugas_antrian.model.LoginResponse
import okefx.okefx.utils.Utility

class LoginPresenter(var mView: LoginContract.LoginView?) : BasePresenter<LoginContract.LoginView>(),
    LoginContract.LoginPresenter {

    val apiManager = ApiManager((mView as BaseActivity))
    private lateinit var sharedPreferences: SharedPreferences

    override fun start(view: LoginContract.LoginView) {

    }

    override fun doLogin(name: String, passwd: String) {
        if (!Utility.validateForEmptyEditText(name, passwd)) {
            (mView as BaseActivity).showLoading()
            apiManager.doLogin(name, passwd, object : ResponseCallBack<LoginResponse> {
                override fun onSuccess(response: LoginResponse) {
                    (mView as BaseActivity).dismissLoading()
                    try {
                        if (response.message == "Success login") {

                           mView?.onLoginResult(true)
                          mView?.showSuccessToast()
                        } else {
                            mView?.showErrorToast()
                        }
                    } catch (ex: Exception) {
                        mView?.showErrorToast()
                    }
                }

                override fun onFailure(e: Throwable) {
                    (mView as BaseActivity).dismissLoading()
                    mView?.showErrorToast()
                }
            })
        } else {
            (mView as BaseActivity).dismissLoading()
            mView?.showErrorToast()
        }
    }

    override fun destroy() {
        mView = null
    }

    override fun moveToNextActivity() {
        //Navigate to appropriate place

    }



}