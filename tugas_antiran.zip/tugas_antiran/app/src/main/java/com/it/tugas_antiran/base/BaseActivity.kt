package com.it.tugas_antrian.base

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.it.tugas_antiran.R
import com.it.tugas_antrian.utils.DialogLoading

abstract class BaseActivity : AppCompatActivity(), BaseView {

    var dialogLoading: DialogLoading? = null

    fun getDialogLoadings() : DialogLoading{
        if(dialogLoading == null){
            dialogLoading = DialogLoading(this, R.style.DialogCustom)
        }
        return dialogLoading!!
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(getLayout())
        initView()

    }

    fun showLoading() {
        getDialogLoadings().show()
    }

    fun dismissLoading(){
        if(getDialogLoadings().isShowing){
            getDialogLoadings().dismiss()
        }
    }

    protected abstract fun getLayout(): Int
    protected abstract fun initView()

    abstract override fun showErrorToast()

    abstract override fun showSuccessToast()

}