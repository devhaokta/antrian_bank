package com.it.tugas_antiran

import android.content.Intent
import android.text.InputType
import android.widget.Toast
import com.it.tugas_antiran.Login
import com.it.tugas_antiran.R
import com.it.tugas_antrian.DaftarContract
import com.it.tugas_antrian.DaftarPresenter
import com.it.tugas_antrian.base.BaseActivity
import kotlinx.android.synthetic.main.activity_daftar.*


class DaftarActivity :  BaseActivity(), DaftarContract.DaftarView {

    private val mPresenter = DaftarPresenter(this)
    override fun getLayout(): Int {
        return R.layout.activity_daftar
    }

    override fun initView() {

        etEmail.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        etNama.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        etPass.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        etNo.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        etUser.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        btnLanjut.setOnClickListener {
            onDaftarBtnClick()
        }
    }

    override fun onDaftarBtnClick() {
        mPresenter.doDaftar(etNama.text.toString(),etEmail.text.toString()
            ,etUser.text.toString(),etPass.text.toString(),Integer.valueOf(etNo.text.toString()))
    }

    override fun onDaftarResult(result: Boolean?) {
        moveToNextScreen()
    }

    override fun moveToNextScreen() {
        startActivity(Intent(this@DaftarActivity, Login::class.java))
        finish()
    }

    override fun showErrorToast() {
        Toast.makeText(this, getString(R.string.error_toast), Toast.LENGTH_SHORT).show()

    }

    override fun showSuccessToast() {
        Toast.makeText(this, "Berhasil daftar , silahkan login .", Toast.LENGTH_SHORT).show()
    }


}