package com.it.tugas_antrian.model

data class LoginResponse(
    val message: String,
    val value: Value
)
{
data class Value(
    val email: String,
    val id: Int,
    val nama: String,
    val no_telepon: String,
    val password: String,
    val username: String
)}