package com.it.tugas_antrian


import com.it.tugas_antrian.api.ApiManager
import com.it.tugas_antrian.api.ResponseCallBack
import com.it.tugas_antrian.base.BaseActivity
import com.it.tugas_antrian.base.BasePresenter
import com.it.tugas_antrian.model.ApiResponse
import okefx.okefx.utils.Utility

class DaftarPresenter(var mView: DaftarContract.DaftarView?) : BasePresenter<DaftarContract.DaftarView>(),
    DaftarContract.DaftarPresenter {

    val apiManager = ApiManager((mView as BaseActivity))
    override fun start(view: DaftarContract.DaftarView) {
        TODO("Not yet implemented")
    }

    override fun destroy() {
        mView = null
    }

    override fun doDaftar(
        nama: String,
        email: String,
        username: String,
        password: String,
        no_tlp: Int
    ) {
        if (!Utility.validateForEmptyEditText(nama, email , username , password  )) {
            (mView as BaseActivity).showLoading()
            apiManager.doDaftar(nama ,email,username,password,no_tlp, object :
                ResponseCallBack<ApiResponse> {
                override fun onSuccess(response: ApiResponse) {
                    (mView as BaseActivity).dismissLoading()
                    try {
                        if (response.message == "Success!") {
                            mView?.showSuccessToast()
                            mView?.onDaftarResult(true)
                        } else {
                            mView?.showErrorToast()

                        }
                    } catch (ex: Exception) {
                        mView?.showErrorToast()
                    }
                }

                override fun onFailure(e: Throwable) {
                    (mView as BaseActivity).dismissLoading()
                    mView?.showErrorToast()

                }
            })
        } else {
            (mView as BaseActivity).dismissLoading()
            mView?.showErrorToast()
        }
    }



}