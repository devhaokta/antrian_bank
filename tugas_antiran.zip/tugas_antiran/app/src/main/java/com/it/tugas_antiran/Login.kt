package com.it.tugas_antiran

import android.content.Intent
import android.widget.Toast
import com.it.tugas_antrian.base.BaseActivity
import com.it.tugas_antrian.login.LoginContract
import com.it.tugas_antrian.login.LoginPresenter
import kotlinx.android.synthetic.main.activity_login.*

class Login : BaseActivity(), LoginContract.LoginView {

    private val mPresenter = LoginPresenter(this)

    override fun getLayout(): Int {
        return R.layout.activity_login
    }

    override fun initView() {
        if(intent.hasExtra("401Message")){
            Toast.makeText(applicationContext, intent.getStringExtra("401Message"), Toast.LENGTH_SHORT).show()
        }
        //      checkAlreadyLogin()

        if(BuildConfig.DEBUG){
         etEmail.setText("")
          etPass.setText("")
        }
        btnLanjut.setOnClickListener {
            onLoginBtnClick()

        }
        tvDaftar.setOnClickListener {
            startActivity(Intent(this@Login, DaftarActivity::class.java))

            finish()
        }

    }

    override fun checkAlreadyLogin() {
        TODO("Not yet implemented")
    }

    override fun onLoginBtnClick() {
        mPresenter.doLogin(etEmail.text.toString(), etPass.text.toString())

    }

    override fun onLoginResult(result: Boolean?) {
        moveToNextScreen()

    }

    override fun moveToNextScreen() {
        startActivity(Intent(this@Login, MainActivity::class.java))

        finish()
    }




    override fun saveToken(token: String) {
        TODO("Not yet implemented")
    }

    override fun showErrorToast() {
        Toast.makeText(this, getString(R.string.error_toast), Toast.LENGTH_SHORT).show()
    }

    override fun showSuccessToast() {
        Toast.makeText(this, getString(R.string.success_toast), Toast.LENGTH_SHORT).show()
    }



}