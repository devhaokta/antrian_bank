package com.it.tugas_antrian.api

import android.content.Context
import android.util.Log
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.it.tugas_antiran.BuildConfig
import com.it.tugas_antiran.BuildConfig.BASE_URL
import com.it.tugas_antiran.utils.RxErrorHandlingCallAdapterFactory
import com.it.tugas_antiran.utils.SPHelper
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import retrofit2.converter.gson.GsonConverterFactory
import java.lang.reflect.Modifier


class ApiClient {

    companion object {
        var retrofit: Retrofit? = null
        var retrofitAuth: Retrofit? = null

        private val gson = GsonBuilder()
            .excludeFieldsWithModifiers(Modifier.FINAL, Modifier.TRANSIENT, Modifier.STATIC)
            //         .setDateFormat("yyyy-MM-dd'T'HH:mm:ssZ")
            .setLenient()
            .serializeNulls()
            .create()

        fun getClient(): Retrofit {
            if (retrofit == null) {
                val gson = Gson()
                val logInterceptor = HttpLoggingInterceptor()
                logInterceptor.level = HttpLoggingInterceptor.Level.BODY
                val okHttpClient: OkHttpClient =
                    OkHttpClient().newBuilder().addInterceptor(logInterceptor)
                        .build()

                retrofit = Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                    .addConverterFactory(GsonConverterFactory.create(gson))
                    .client(okHttpClient)
                    .build()
            }
            return retrofit as Retrofit
        }



    }


}