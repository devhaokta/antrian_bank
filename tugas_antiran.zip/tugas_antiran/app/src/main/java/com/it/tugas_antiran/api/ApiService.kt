package com.it.tugas_antrian.api

import android.content.Context
import com.it.tugas_antrian.model.*
import io.reactivex.Observable
import io.reactivex.Single
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import retrofit2.Call
import retrofit2.http.*

interface ApiService{

    @FormUrlEncoded
    @POST("user/auth")
    fun login(@Field("username") userEmail: String,
              @Field("password") userPassword: String): Observable<LoginResponse>

    @FormUrlEncoded
    @POST("user/store")
    fun daftar(@Field("nama") userNama: String,
               @Field("email") userEmail: String,
               @Field("username") userName: String,
               @Field("password") userPassword: String,
               @Field("no_telepon") userNo: Int): Observable<ApiResponse>



}