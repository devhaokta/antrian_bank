package com.it.tugas_antrian.base
interface BaseView {

    fun showErrorToast()
    fun showSuccessToast()
}