package com.it.tugas_antrian.api

import android.content.Context
import com.it.tugas_antrian.model.*
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class ApiManager(val context: Context) {

    val apiClient = ApiClient.getClient().create(ApiService::class.java)

    fun doLogin(username: String, passwd: String, responseListener: ResponseCallBack<LoginResponse>) {
        apiClient.login(username, passwd)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe({ response: LoginResponse -> responseListener.onSuccess(response) },
                { e: Throwable -> run { responseListener.onFailure(e) } })
    }

    fun doDaftar(nama: String, email: String, username: String ,password: String , no_tlp: Int
        ,responseListener: ResponseCallBack<ApiResponse>) {
        apiClient.daftar(nama, email , username , password  , no_tlp)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe({ response: ApiResponse -> responseListener.onSuccess(response) },
                { e: Throwable -> run { responseListener.onFailure(e) } })
    }



}

