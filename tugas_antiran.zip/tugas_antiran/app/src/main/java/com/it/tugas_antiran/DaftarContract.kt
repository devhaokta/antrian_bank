package com.it.tugas_antrian

import com.it.tugas_antrian.base.BaseView

interface DaftarContract {

    interface DaftarView : BaseView {
        fun onDaftarBtnClick()
        fun onDaftarResult(result: Boolean?)
        fun moveToNextScreen()
    }

    interface DaftarPresenter {
        fun doDaftar(nama: String, email: String, username: String ,password: String , no_tlp:Int)

    }

}